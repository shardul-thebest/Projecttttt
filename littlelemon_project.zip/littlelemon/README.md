# Little Lemon Booking Website

Django backend for a Little Lemon restaurant booking form, using MySQL and JavaScript `fetch()`.

## Project structure
- Django project: `littlelemon`
- Django app: `restaurant`
- Booking form: `/book/`
- Reservations JSON: `/reservations/`
- Date-filtered bookings API: `/bookings/?date=YYYY-MM-DD`

## Requirements
- Python 3.11 (or a compatible Python version)
- Pipenv
- MySQL server running locally

## Setup
1. Create a MySQL database:
   ```sql
   CREATE DATABASE littlelemon CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
   ```
2. Copy `.env.example` to `.env` and update your local MySQL credentials. The settings read environment variables; export them in your shell if you do not use a tool to load `.env`.
3. Install dependencies:
   ```bash
   pipenv install
   pipenv shell
   ```
4. Set MySQL environment variables in your terminal before running Django, for example on macOS/Linux:
   ```bash
   export MYSQL_DATABASE=littlelemon
   export MYSQL_USER=root
   export MYSQL_PASSWORD='your_mysql_password'
   export MYSQL_HOST=127.0.0.1
   export MYSQL_PORT=3306
   ```
   On Windows PowerShell, use `$env:MYSQL_DATABASE="littlelemon"` and equivalent commands for the other values.
5. Run migrations and start the server:
   ```bash
   python manage.py makemigrations restaurant
   python manage.py migrate
   python manage.py runserver
   ```
6. Open `http://127.0.0.1:8000/` or `http://127.0.0.1:8000/book/`.

## Features
- Booking form with first name, reservation date, and reservation slot.
- Current date selected automatically.
- Date changes trigger `fetch()` to reload availability.
- Already-booked time slots are disabled in the selector.
- Server-side validation prevents duplicate bookings for the same date and slot.
- `/reservations/` returns all bookings as JSON.
- `/bookings/?date=2026-10-29` returns bookings for one date; without `date`, it returns all bookings.
- A “No Booking” message is shown when the selected date has no bookings.

## Notes
- Database credentials are intentionally local configuration, not included as real secrets.
- This project is intended for coursework/local review. For production, configure authentication, CSRF strategy, secure secrets, validation/rate limiting, and deployment settings.
