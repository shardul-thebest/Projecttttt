document.addEventListener("DOMContentLoaded", () => {
  const form = document.getElementById("booking-form");
  if (!form) return;

  const dateInput = document.getElementById("reservation_date");
  const slotSelect = document.getElementById("reservation_slot");
  const message = document.getElementById("form-message");
  const reservationList = document.getElementById("current-reservations");
  const noBooking = document.getElementById("no-booking");
  const dateLabel = document.getElementById("reservation-date-label");
  const csrfInput = form.querySelector("[name=csrfmiddlewaretoken]");

  const setMessage = (text, isError = false) => {
    message.textContent = text;
    message.style.color = isError ? "#a32626" : "#28613e";
  };

  async function refreshBookings() {
    const selectedDate = dateInput.value;
    dateLabel.textContent = selectedDate ? `Reservations for ${selectedDate}` : "";
    reservationList.replaceChildren();
    noBooking.hidden = true;

    // Re-enable all options before applying the selected date's booked slots.
    Array.from(slotSelect.options).forEach(option => {
      option.disabled = false;
      option.textContent = option.value;
    });

    try {
      const response = await fetch(`/bookings?date=${encodeURIComponent(selectedDate)}`, {
        headers: { "Accept": "application/json" }
      });
      if (!response.ok) throw new Error("Could not load reservations.");
      const bookings = await response.json();
      const bookedSlots = new Set(bookings.map(item => item.reservation_slot));

      Array.from(slotSelect.options).forEach(option => {
        if (bookedSlots.has(option.value)) {
          option.disabled = true;
          option.textContent = `${option.value} — Booked`;
        }
      });

      if (slotSelect.selectedOptions.length && slotSelect.selectedOptions[0].disabled) {
        const available = Array.from(slotSelect.options).find(option => !option.disabled);
        if (available) slotSelect.value = available.value;
      }

      if (bookings.length === 0) {
        noBooking.hidden = false;
        noBooking.textContent = "No Booking for this date.";
      } else {
        bookings.forEach(booking => {
          const li = document.createElement("li");
          li.textContent = `${booking.reservation_slot} — ${booking.first_name}`;
          reservationList.appendChild(li);
        });
      }
    } catch (error) {
      setMessage(error.message, true);
    }
  }

  dateInput.addEventListener("change", () => {
    setMessage("");
    refreshBookings();
  });

  form.addEventListener("submit", async event => {
    event.preventDefault();
    setMessage("");
    const payload = {
      first_name: document.getElementById("first_name").value.trim(),
      reservation_date: dateInput.value,
      reservation_slot: slotSelect.value
    };

    if (!payload.first_name || !payload.reservation_date || !payload.reservation_slot) {
      setMessage("Please complete all fields.", true);
      return;
    }
    if (slotSelect.selectedOptions[0]?.disabled) {
      setMessage("That time slot is already booked. Please choose another.", true);
      return;
    }

    try {
      const response = await fetch("/bookings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Accept": "application/json",
          "X-CSRFToken": csrfInput ? csrfInput.value : ""
        },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (!response.ok) {
        setMessage(data.error || "Booking could not be saved.", true);
        await refreshBookings();
        return;
      }
      setMessage("Your table has been reserved!");
      form.reset();
      // Keep today's date as the default after a successful submission.
      if (!dateInput.value) dateInput.value = new Date().toISOString().slice(0, 10);
      await refreshBookings();
    } catch (error) {
      setMessage("Could not contact the server. Please try again.", true);
    }
  });

  refreshBookings();
});
