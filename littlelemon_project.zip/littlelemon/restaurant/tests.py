import json
from datetime import date, timedelta
from django.test import TestCase
from django.urls import reverse
from .models import Booking

class BookingAPITests(TestCase):
    def test_reservations_endpoint_returns_json(self):
        Booking.objects.create(first_name="Ava", reservation_date=date.today(), reservation_slot="18:00")
        response = self.client.get("/reservations/")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json()[0]["first_name"], "Ava")

    def test_filter_by_date(self):
        today = date.today()
        Booking.objects.create(first_name="Ava", reservation_date=today, reservation_slot="18:00")
        response = self.client.get(f"/bookings?date={today.isoformat()}")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(len(response.json()), 1)

    def test_duplicate_slot_is_rejected(self):
        today = date.today()
        Booking.objects.create(first_name="Ava", reservation_date=today, reservation_slot="18:00")
        response = self.client.post(
            "/bookings",
            data=json.dumps({"first_name": "Noah", "reservation_date": today.isoformat(), "reservation_slot": "18:00"}),
            content_type="application/json",
        )
        self.assertEqual(response.status_code, 409)

    def test_no_bookings_returns_empty_list(self):
        response = self.client.get(f"/bookings?date={(date.today() + timedelta(days=1)).isoformat()}")
        self.assertEqual(response.status_code, 200)
        self.assertEqual(response.json(), [])
