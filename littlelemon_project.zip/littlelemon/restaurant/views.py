import json
from datetime import date
from django.db import IntegrityError, transaction
from django.http import JsonResponse
from django.shortcuts import render
from django.views.decorators.http import require_GET, require_http_methods
from .models import Booking

TIME_SLOTS = [
    "12:00", "13:00", "14:00", "15:00", "16:00",
    "17:00", "18:00", "19:00", "20:00", "21:00",
]

def home(request):
    return render(request, "restaurant/home.html")

def booking_page(request):
    return render(request, "restaurant/book.html", {"today": date.today().isoformat(), "time_slots": TIME_SLOTS})

def reservations_page(request):
    # This route is intentionally JSON, as required by the assessment.
    bookings = Booking.objects.all().values("id", "first_name", "reservation_date", "reservation_slot")
    data = [
        {
            "id": row["id"],
            "first_name": row["first_name"],
            "reservation_date": row["reservation_date"].isoformat(),
            "reservation_slot": row["reservation_slot"],
        }
        for row in bookings
    ]
    return JsonResponse(data, safe=False)

@require_http_methods(["GET", "POST"])
def bookings_api(request):
    if request.method == "GET":
        selected_date = request.GET.get("date")
        qs = Booking.objects.all()
        if selected_date:
            try:
                date.fromisoformat(selected_date)
            except ValueError:
                return JsonResponse({"error": "Invalid date. Use YYYY-MM-DD."}, status=400)
            qs = qs.filter(reservation_date=selected_date)
        data = [
            {
                "id": b.id,
                "first_name": b.first_name,
                "reservation_date": b.reservation_date.isoformat(),
                "reservation_slot": b.reservation_slot,
            }
            for b in qs
        ]
        return JsonResponse(data, safe=False)

    try:
        payload = json.loads(request.body.decode("utf-8"))
    except (json.JSONDecodeError, UnicodeDecodeError):
        return JsonResponse({"error": "Request body must be valid JSON."}, status=400)

    first_name = str(payload.get("first_name", "")).strip()
    reservation_date = str(payload.get("reservation_date", "")).strip()
    reservation_slot = str(payload.get("reservation_slot", "")).strip()

    if not first_name or not reservation_date or not reservation_slot:
        return JsonResponse({"error": "First name, reservation date, and reservation slot are required."}, status=400)
    try:
        parsed_date = date.fromisoformat(reservation_date)
    except ValueError:
        return JsonResponse({"error": "Reservation date must use YYYY-MM-DD."}, status=400)
    if reservation_slot not in TIME_SLOTS:
        return JsonResponse({"error": "Invalid reservation slot."}, status=400)
    if parsed_date < date.today():
        return JsonResponse({"error": "Reservation date cannot be in the past."}, status=400)

    try:
        with transaction.atomic():
            booking = Booking.objects.create(
                first_name=first_name[:100],
                reservation_date=parsed_date,
                reservation_slot=reservation_slot,
            )
    except IntegrityError:
        return JsonResponse({"error": "That time slot is already booked for this date."}, status=409)

    return JsonResponse({
        "id": booking.id,
        "first_name": booking.first_name,
        "reservation_date": booking.reservation_date.isoformat(),
        "reservation_slot": booking.reservation_slot,
    }, status=201)
